var searchData=
[
  ['emptynodeexception',['EmptyNodeException',['../class_empty_node_exception.html#a3e485d46169ee32e9aedfea6d01f146c',1,'EmptyNodeException::EmptyNodeException()'],['../class_empty_node_exception.html#a40d040918c5a3e7253facfe18f4b17ff',1,'EmptyNodeException::EmptyNodeException(std::string cause)']]]
];
