var searchData=
[
  ['rtrim',['rtrim',['../trimmer_8h.html#aeb0502cfa0286df2ea5da76564fbc0d9',1,'trimmer.h']]]
];
