var searchData=
[
  ['what',['what',['../class_general__exception.html#a1dae6c5a03ea5e6313d5c99082237c47',1,'General_exception']]]
];
