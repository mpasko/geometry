var searchData=
[
  ['unexpected_5fenum_5fvalue_5fexception',['Unexpected_enum_value_exception',['../class_unexpected__enum__value__exception.html',1,'Unexpected_enum_value_exception'],['../class_unexpected__enum__value__exception.html#a8fce70385494caed464568c5f01a55f2',1,'Unexpected_enum_value_exception::Unexpected_enum_value_exception()'],['../class_unexpected__enum__value__exception.html#ae7e11c48a5d1d0107d914e3c689b25ea',1,'Unexpected_enum_value_exception::Unexpected_enum_value_exception(std::string cause)']]],
  ['unexpected_5fenum_5fvalue_5fexception_2eh',['Unexpected_enum_value_exception.h',['../_unexpected__enum__value__exception_8h.html',1,'']]],
  ['unexpected_5fsubdivision',['Unexpected_subdivision',['../class_unexpected__subdivision.html',1,'Unexpected_subdivision'],['../class_unexpected__subdivision.html#a3decf843d18644f76d63efb03aedc583',1,'Unexpected_subdivision::Unexpected_subdivision()'],['../class_unexpected__subdivision.html#a3c270c5fc8e70199288ed8b0d3a12250',1,'Unexpected_subdivision::Unexpected_subdivision(std::string cause)']]],
  ['unexpected_5fsubdivision_2eh',['unexpected_subdivision.h',['../unexpected__subdivision_8h.html',1,'']]]
];
