var searchData=
[
  ['vertices_5fnumber',['vertices_number',['../class_polygon.html#a8ac65961178f1e3ccbce064496d0e453',1,'Polygon']]]
];
