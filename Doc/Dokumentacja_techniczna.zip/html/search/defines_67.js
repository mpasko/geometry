var searchData=
[
  ['green',['green',['../_visualization_8h.html#a7027592d032f7d20b38a1304ae3da2a2',1,'Visualization.h']]]
];
