var searchData=
[
  ['unexpected_5fenum_5fvalue_5fexception',['Unexpected_enum_value_exception',['../class_unexpected__enum__value__exception.html',1,'']]],
  ['unexpected_5fsubdivision',['Unexpected_subdivision',['../class_unexpected__subdivision.html',1,'']]]
];
