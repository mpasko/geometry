var searchData=
[
  ['operator_2b_3d',['operator+=',['../class_flush_table.html#a2d023cea1bdf7bbd23a07bb64b91e8b1',1,'FlushTable::operator+=()'],['../class_polygon.html#a56412a374c4c51da35d25b194592ba37',1,'Polygon::operator+=()']]],
  ['operator_3d_3d',['operator==',['../class_point.html#ae44b1b6182f029c3e7c16da17d4f47af',1,'Point']]],
  ['operator_5b_5d',['operator[]',['../class_polygon.html#a9a26f15c70bf87f062c42b087f67d422',1,'Polygon']]],
  ['orientation2d',['orientation2d',['../geometry_8h.html#aacabcdb2a381497d8ad68273cc2545a4',1,'orientation2d(Point pointA, Point pointB, Point pointC):&#160;geometry.h'],['../geometry_8h.html#aa1b6cbfa06804d8fca54f2a31a503553',1,'orientation2D(Point pointA, Point pointB, Point pointC):&#160;geometry.h']]],
  ['outputmanager',['OutputManager',['../class_output_manager.html#a33022c5dd792fbe6c2c027c41148d89f',1,'OutputManager::OutputManager(Polygon *&amp;polygon, QuadTree *&amp;quadtree, std::ofstream *&amp;out_stream)'],['../class_output_manager.html#acbbbd60acb46da765c777899a63687be',1,'OutputManager::OutputManager(std::list&lt; Point * &gt; *&amp;points_set, QuadTree *&amp;quadtree, std::ofstream *&amp;out_stream)']]]
];
