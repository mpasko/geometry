var searchData=
[
  ['ltrim',['ltrim',['../trimmer_8h.html#abc3e05de3b9a7518e4b79f789ac32fc2',1,'trimmer.h']]]
];
