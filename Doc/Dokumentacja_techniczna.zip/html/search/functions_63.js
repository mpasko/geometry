var searchData=
[
  ['create_5fextended_5fneighbour',['create_extended_neighbour',['../class_quad_tree.html#ae04de86354dd6fc0438421397bfa6f5d',1,'QuadTree']]],
  ['create_5fextended_5fneighbours',['create_extended_neighbours',['../class_quad_tree.html#acca230327665bf4bfad10682aa37057b',1,'QuadTree']]]
];
