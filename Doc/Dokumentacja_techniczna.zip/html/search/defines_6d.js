var searchData=
[
  ['method_5f1',['METHOD_1',['../triangulation_8h.html#a5751e6809f729905b764ac0fd07a41c9',1,'triangulation.h']]]
];
