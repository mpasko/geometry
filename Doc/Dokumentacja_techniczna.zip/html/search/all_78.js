var searchData=
[
  ['x',['x',['../class_merge_table.html#a4aed2fc6f2b0399721d774a7aa31469e',1,'MergeTable::x()'],['../class_point.html#ab99c56589bc8ad5fa5071387110a5bc7',1,'Point::x()']]]
];
