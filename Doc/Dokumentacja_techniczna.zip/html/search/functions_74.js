var searchData=
[
  ['transform',['transform',['../class_quad_tree.html#a0618f3831c582f743e237e4ce5701861',1,'QuadTree']]],
  ['triangulate',['triangulate',['../triangulation_8h.html#aa830ef3cd7097cdd956b99c44d2d9d72',1,'triangulate(std::ostream &amp;out, QuadTree *qt):&#160;triangulation.h'],['../triangulation_8h.html#a4a44ae13315e1477e284d7747cdab687',1,'triangulate(std::ostream &amp;out, QuadTree *qt, const char *color):&#160;triangulation.h']]],
  ['trim',['trim',['../trimmer_8h.html#a1fd5b09c2d05ba0c3530ce327b9bf1eb',1,'trimmer.h']]]
];
