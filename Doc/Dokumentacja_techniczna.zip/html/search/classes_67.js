var searchData=
[
  ['general_5fexception',['General_exception',['../class_general__exception.html',1,'']]]
];
