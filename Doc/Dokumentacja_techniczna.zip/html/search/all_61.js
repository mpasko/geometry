var searchData=
[
  ['are_5fpoints_5fequal',['are_points_equal',['../geometry_8h.html#a00e84be91ad79035afd1e63b568b82c3',1,'geometry.h']]]
];
