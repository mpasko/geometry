var searchData=
[
  ['numberformatexception',['NumberFormatException',['../class_number_format_exception.html#a8bf70dad451544c587e11531ce5015c1',1,'NumberFormatException::NumberFormatException()'],['../class_number_format_exception.html#aa8f0766a9abf132497ec9f4c5f9b7464',1,'NumberFormatException::NumberFormatException(std::string cause)']]]
];
