var searchData=
[
  ['red',['red',['../_visualization_8h.html#ab435487e41a1d42d4379464e35f873b4',1,'Visualization.h']]]
];
